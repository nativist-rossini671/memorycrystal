# Memory Crystal — Brand Guide

Updated SVG lockups now match the PNG package styling, with uppercase `MEMORY CRYSTAL` text to match the rendered exports.

## Included
- icon-only PNGs
- lockup PNGs
- corrected SVG sources
- brand guide preview
