# Memory Crystal — Brand Guide

## Logo Files

### Icon Only (`icon-only/`)
| File | Description |
|------|-------------|
| `icon-transparent.png` | Crystal icon, glow, transparent background |
| `icon-on-dark.png` | Crystal icon, glow, on #0d1820 dark background |
| `icon-large-transparent.png` | 256px icon, transparent, high-res |

### Full Lockup (`lockup/`)
| File | Description |
|------|-------------|
| `lockup-on-dark.png` | Full logo on dark navy background |
| `lockup-on-white.png` | Full logo on white background |
| `lockup-transparent.png` | Full logo, transparent bg (for dark-bg placement) |

### SVG Source (`svg-source/`)
| File | Description |
|------|-------------|
| `crystal-icon.svg` | Standalone crystal icon (scalable) |
| `lockup-light.svg` | Full wordmark for dark backgrounds |
| `lockup-dark.svg` | Full wordmark for light backgrounds |

---

## Brand Colors

| Name | Hex | Usage |
|------|-----|-------|
| Crystal Glow | `#97F0F7` | Icon highlight |
| Crystal Mid | `#4CC1E9` | Icon body / hover |
| Brand Blue | `#2180D6` | Primary text, CTAs |
| Crystal Deep | `#1E6DBB` | Icon base |
| Crystal Dark | `#1C549F` | Icon shadow face |
| Background Dark | `#0D1820` | Primary background |
| Text Secondary | `#7A9AB5` | Muted text |

---

## Typography

**Logo Font:** Audiowide (Google Fonts — free)
- Usage: Logo/wordmark only
- Letter spacing: `0.08em`
- Weight: 400

---

## Glow Effects (dark backgrounds only)

**Icon:** `filter: drop-shadow(0 0 8px rgba(33,128,214,0.6))`
**Text:** `text-shadow: 0 0 20px rgba(33,128,214,0.5), 0 0 40px rgba(33,128,214,0.2)`

---

## Usage Rules

- Minimum icon size: 16px
- Clear space: 1× icon width on all sides
- Do not recolor the crystal gradients
- Do not apply glow on white/light backgrounds
- Do not stretch or distort
